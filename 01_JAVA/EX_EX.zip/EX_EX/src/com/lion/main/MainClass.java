package com.lion.main;

import com.lion.shop.ShopClass;

public class MainClass {
    public static void main(String[] args) {
        ShopClass shopClass = new ShopClass();
        shopClass.startAction();
    }
}
