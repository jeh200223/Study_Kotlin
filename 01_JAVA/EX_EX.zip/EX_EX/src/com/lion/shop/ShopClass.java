package com.lion.shop;

import java.util.Scanner;

public class ShopClass {
    // 상품들을 담을 배열
    private ObjectClass [] ObjectArray;
    // 상품의 수
    private int ObjectCount;
    // 총 가격
    private int totalPrice;
    // 평균 가격
    private int avgPrice;

    private void inputObjectCount(){
        System.out.println("다이소 상품관리");
        Scanner scanner = new Scanner(System.in);
        System.out.print("상품의 수를 입력해주세요 : ");
        ObjectCount = scanner.nextInt();
        ObjectArray = new ObjectClass[ObjectCount];
    }

    private void inputObjectInfo(){
        // 상품수만큼 반복한다.
        for (int i = 0; i < ObjectCount; i++) {
            System.out.println();
            System.out.println("상품 종류");
            System.out.println("1. 로봇청소기");
            System.out.println("2. 한글텀블러");
            System.out.println("3. 충전어뎁터");
            Scanner scanner = new Scanner(System.in);
            int objectType = scanner.nextInt();

            ObjectClass objectClass = null;

            switch (objectType) {
                case ObjectType.TYPE_CLEANER:
                    System.out.println();
                    System.out.println("로봇청소기 정보 입력");
                    objectClass = new CleanerClass(ObjectType.TYPE_CLEANER);
                    break;
                case ObjectType.TYPE_TUMBLER:
                    System.out.println();
                    System.out.println("한글텀블러 정보 입력");
                    objectClass = new TumblerClass(ObjectType.TYPE_TUMBLER);
                    break;
                case ObjectType.TYPE_ADAPTER:
                    System.out.println();
                    System.out.println("충전어뎁터 정보 입력");
                    objectClass = new AdapterClass(ObjectType.TYPE_ADAPTER);
                    break;
            }
            objectClass.inputObjectInfoBase();
            ObjectArray[i] = objectClass;
        }
    }

    private void showtObjectInfo(){
        for (int i = 0; i < ObjectArray.length; i++) {
            totalPrice = totalPrice + ObjectArray[i].returnPrice();
            ObjectArray[i].showObjectInfoBase();
            ObjectArray[i].doAction();
            ObjectArray[i].extraAction();
        }
        avgPrice = totalPrice / ObjectCount;
        System.out.println();
        System.out.printf("전체 상품의 개수 : %d개\n", ObjectCount);
        System.out.printf("총 가격 : %d원\n", totalPrice);
        System.out.printf("평균 가격 : %d원\n", avgPrice);
    }

    public void startAction() {
        inputObjectCount();
        inputObjectInfo();
        showtObjectInfo();
    }
}
