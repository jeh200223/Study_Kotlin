package com.lion.shop;

public interface SectionType {
    int TYPE_CLEANING = 1;
    int TYPE_NORMAL = 2;
    int TYPE_ELECTRIC = 3;
}
