package com.lion.shop;

public interface ObjectType {
    int TYPE_CLEANER = 1;
    int TYPE_TUMBLER = 2;
    int TYPE_ADAPTER = 3;
}
