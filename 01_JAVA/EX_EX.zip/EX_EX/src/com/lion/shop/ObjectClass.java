package com.lion.shop;

import java.util.Scanner;

public class ObjectClass {
    // 가격
    private int Price;
    // 상품의 종류
    private int ObjectType;
    // 진열공간 메뉴
    private int sectionType;


    public ObjectClass(int ObjectType){
        this.ObjectType = ObjectType;
    }

    public void inputObjectInfoBase() {
        Scanner scanner = new Scanner(System.in);
        System.out.println();
        System.out.print("가격 : ");
        Price = scanner.nextInt();
        System.out.println();
        System.out.println("진열공간");
        System.out.println("1. 청소용품");
        System.out.println("2. 일반용품");
        System.out.println("3. 전기용품");
        sectionType = scanner.nextInt();
    }

    public void showObjectInfoBase() {
        System.out.printf("가격 : %d원\n", Price);
        switch (sectionType) {
            case SectionType.TYPE_CLEANING:
                System.out.println("청소용품");
                break;
            case SectionType.TYPE_NORMAL:
                System.out.println("일반용품");
                break;
            case SectionType.TYPE_ELECTRIC:
                System.out.println("전기용품");
                break;
        }
    }

    // 가격의 정보를 전송하는 메서드
    public int returnPrice () {
        return Price;
    }

    public void doAction() {
    }

    public void extraAction() {
    }
}
