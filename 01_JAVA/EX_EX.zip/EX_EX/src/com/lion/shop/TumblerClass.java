package com.lion.shop;

public class TumblerClass extends ObjectClass{
    public TumblerClass(int ObjectType) {
        super(ObjectType);
    }

    @Override
    public void showObjectInfoBase() {
        System.out.println();
        System.out.println("한글텀블러");
        super.showObjectInfoBase();
    }

    @Override
    public void doAction() {
        System.out.println("물 온도를 유지합니다.");

    }

    @Override
    public void extraAction() {
        attack();
    }

    public void attack() {
        System.out.println("던지면 아픕니다.");
    }
}
