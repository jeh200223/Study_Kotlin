package com.lion.shop;

public class CleanerClass extends ObjectClass{
    public CleanerClass(int ObjectType) {
        super(ObjectType);
    }

    @Override
    public void showObjectInfoBase() {
        System.out.println();
        System.out.println("로봇청소기");
        super.showObjectInfoBase();
    }

    @Override
    public void doAction() {
        System.out.println("청소를 합니다.");
    }

    @Override
    public void extraAction() {
        miss();
    }

    public void miss() {
        System.out.println("장애물을 피하지 못합니다.");
    }
}
