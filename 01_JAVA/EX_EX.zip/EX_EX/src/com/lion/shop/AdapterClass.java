package com.lion.shop;

public class AdapterClass extends ObjectClass{
    public AdapterClass(int ObjectType) {
        super(ObjectType);
    }

    @Override
    public void showObjectInfoBase() {
        System.out.println();
        System.out.println("전기어뎁터");
        super.showObjectInfoBase();
    }

    @Override
    public void doAction() {
        System.out.println("전기를 공급합니다.");
    }

    @Override
    public void extraAction() {
        heart();
    }

    public void heart() {
        System.out.println("먹으면 다칩니다.");
    }
}
