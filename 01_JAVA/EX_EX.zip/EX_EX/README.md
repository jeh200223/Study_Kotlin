다땡소 상품관리

상품 정보를 입력받고 상품 정보를 출력한다.

상품
상품명 : 로봇청소기
가격 : 얼마원
진열공간 : 청소용품
청소를 하는 기능
장애물을 피하지 못하는 기능

상품명 : 한글텀블러
가격 : 얼마원
진열공간 : 일반용품
물 온도를 유지하는 기능
던지면 아파요~ 기능

상품명 : 충전어뎁터
가격 : 얼마원
진열공간 : 전기용품
전기를 공급하는 기능
먹으면 다쳐요

가격은 자유롭게 입력을 받는다.
상품의 종류와 진열공간 메뉴로 제공하여
메뉴 번호를 입력하게 한다.

청소를 하는 기능, 물 온도를 유지하는 기능, 전기를 공급하는 기능
-> doAction 이라는 메서드로 구현한다.

장애물을 피하지 못하는 기능, 던지면 아파요~ 기능, 먹으면 다쳐요
-> 각각 다른 이름으로 메서를 구현해주세요.

전체 상품의 개수를 입력받는다.
상품 정보를 먼저 입력받는다.
상품 정보들을 출력한다.

전체 상품의 개수 : 몇개
전체 가격 : 얼마얼마원
평균 가격 : 얼마얼마원

### 패키지를 만들어준다
- com.lion.main
- com.lion.shop

### 출력문을 만든다.
```java
public static void main(String[] args) {
        System.out.println("상품");
        System.out.println("상품명 : 로봇청소기");
        System.out.println("가격 : 5000원");
        System.out.println("진열공간 : 청소용품");
        System.out.println("청소를 합니다.");
        System.out.println("장애물을 피하지 못합니다.");

        System.out.println("상품명 : 한글텀블러");
        System.out.println("가격 : 7000원");
        System.out.println("진열공간 : 일반용품");
        System.out.println("물 온도를 유지합니다.");
        System.out.println("던지면 아픕니다.");

        System.out.println("상품명 : 충전어뎁터");
        System.out.println("가격 : 5000원");
        System.out.println("진열공간 : 전기용품");
        System.out.println("충전을 해줍니다.");
        System.out.println("먹으면 다칩니다.");
    }
```

### 필요한 정보들을 정리한다
- 상품명
- 가격
- 진열공간
- 청소를 합니다.
- 장애물을 피하지 못합니다.
- 물 온도를 유지합니다.
- 던지면 아픕니다.
- 충전을 해줍니다.
- 먹으면 다칩니다.

### 필요한 정보들을 구분한다
- 상품명 - 공용
- 가격 - 공용
- 진열공간 - 공용
- 청소를 합니다. - 로봇청소기
- 장애물을 피하지 못합니다. - 로봇청소기
- 물 온도를 유지합니다. - 한글텀블러
- 던지면 아픕니다. - 한글텀블러
- 충전을 해줍니다. - 충전어뎁터
- 먹으면 다칩니다. - 충전어뎁터

### shop패키지에 ShopClass, ObjectClass, CleanerClass, TumblerClass, AdapterClass를 만들어준다.

### ObjectClass에 공통으로 필요한 변수를 만들어준다.
```java
// 가격
int Price;
// 상품의 종류
int ObjectType;
// 진열공간 메뉴
int SectionType;
```

### ObjectClass에 공통으로 필요한 메서드를 만들어준다.
```java
public void inputObjectInfoBase() {

}

public void showObjectInfoBase() {

}

public void doAction() {

}

public void extraAction() {
}
```

### ObjectClass에 공통으로 입력받는 메서드를 작성해준다.
```java
public void inputObjectInfo() {
    Scanner scanner = new Scanner(System.in);
    System.out.println();
    System.out.print("가격 : ");
    Price = scanner.nextInt();
    System.out.println();
    System.out.println("진열공간");
    System.out.println("1. 청소용품");
    System.out.println("2. 일반용품");
    System.out.println("3. 전기용품");
    sectionType = scanner.nextInt();
    }
```

### ObjectClass에 상품의 종류와 진열공간 메뉴를 받을 메서드를 만들어준다.
```java
public ObjectClass(int ObjectType){
        this.ObjectType = ObjectType;
    }
```

### CleanerClass, TumblerClass, AdapterClass에 ObjectClass를 부모로 만들어준다.

### TumblerClass에 필요한 메서드를 만들어준다.
```java
public class TumblerClass extends ObjectClass{
    public TumblerClass(int ObjectType) {
        super(ObjectType);
    }

    @Override
    public void showObjectInfoBase() {
        
    }

    @Override
    public void doAction() {
       

    }

    @Override
    public void extraAction() {
       
    }

    public void attack() {
        
    }
}
```

### CleanerClass에 필요한 메서드를 만들어준다.
```java
public class CleanerClass extends ObjectClass {
    public CleanerClass(int ObjectType) {
        super(ObjectType);
    }

    @Override
    public void showObjectInfoBase() {

    }

    @Override
    public void doAction() {

    }

    @Override
    public void extraAction() {

    }

    public void miss() {

    }
}
```

### AdapterClass에 필요한 메서드를 만들어준다.
```java
public class CleanerClass extends ObjectClass {
    public TumblerClass(int ObjectType) {
        super(ObjectType);
    }

    @Override
    public void showObjectInfoBase() {

    }

    @Override
    public void doAction() {


    }

    @Override
    public void extraAction() {

    }

    public void attack() {

    }
}
```

### ObjectType 인터페이스를 만들어준다.
```java
public interface Values {
    int TYPE_CLEANER = 1;
    int TYPE_TUMBLER = 2;
    int TYPE_ADAPTER = 3;
}
```

### SectionType 인터페이스를 만들어준다.
```java
public interface Values {
    int TYPE_CLEANING = 1;
    int TYPE_NORMAL = 2;
    int TYPE_ELECTRIC = 3;
}
```

### ShopClass에 변수를 만들어준다.
```java
// 상품들을 담을 배열
    ObjectClass [] ObjectArray;
    // 상품의 수
    int ObjectCount;
```

### ShopClass에 필요한 메서드를 만들어준다.
```java
public void inputObjectCount(){
        
    }
    
    public void inputObjectInfo(){
        
    }
    
    public void showtObjectInfo(){

    }
```

### ShopClass에 상품의 수를 입력받는 메서드를 직상해준다.
```java
public void inputObjectCount(){
        System.out.println("다이소 상품관리");
        Scanner scanner = new Scanner(System.in);
        System.out.print("상품의 수를 입력해주세요 : ");
        ObjectCount = scanner.nextInt();
    }
```

### ShopClass에 상품종류를 입력받는 부분을 직성해준다.
```java
public void inputObjectInfo(){
    // 상품수만큼 반복한다.
    for (int i = 0; i < ObjectCount; i++) {
        System.out.println("상품 종류");
        System.out.println("1. 로봇청소기");
        System.out.println("2. 한글텀블러");
        System.out.println("3. 충전어뎁터");
        Scanner scanner = new Scanner(System.in);
        int ObjectType = scanner.nextInt();

        ObjectClass objectClass = null;

        switch (ObjectType) {
            case Values.TYPE_CLEANER:
                objectClass = new CleanerClass(Values.TYPE_CLEANER);
                break;
            case Values.TYPE_TUMBLER:
                objectClass = new TumblerClass(Values.TYPE_TUMBLER);
                break;
            case Values.TYPE_ADAPTER:
                objectClass = new AdapterClass(Values.TYPE_ADAPTER);
                break;
        }
        objectClass.inputObjectInfoBase();
        ObjectArray[i] = objectClass;
    }
}
```

### ShopClass에 상품종류를 출력하는 부분을 직성해준다.
```java
public void showtObjectInfo(){
        for (int i = 0; i < ObjectArray.length; i++) {
            ObjectArray[i].showObjectInfoBase();
            ObjectArray[i].doAction();
            ObjectArray[i].extraAction();
        }
    }
```

### ObjectClass에 공통으로 출력하는 부분을 만들어준다.
```java
public void showObjectInfoBase() {
        System.out.printf("가격 : %d원\n", Price);
        switch (sectionType) {
            case SectionType.TYPE_CLEANING:
                System.out.println("청소용품");
                break;
            case SectionType.TYPE_NORMAL:
                System.out.println("일반용품");
                break;
            case SectionType.TYPE_ELECTRIC:
                System.out.println("전기용품");
                break;
        }
    }
```

### AdapterClass의 출력부분과 기능들을 만들어준다.
```java
@Override
public void showObjectInfoBase() {
    System.out.println();
    System.out.println("전기어뎁터");
    super.showObjectInfoBase();
}

@Override
public void doAction() {
    System.out.println("전기를 공급합니다.");
}

@Override
public void extraAction() {
    heart();
}

public void heart() {
    System.out.println("먹으면 다칩니다.");
}
```

### TumblerClass의 출력부분과 기능들을 만들어준다.
```java
@Override
public void showObjectInfoBase() {
    System.out.println();
    System.out.println("한글텀블러");
    super.showObjectInfoBase();
}

@Override
public void doAction() {
    System.out.println("물 온도를 유지합니다.");

}

@Override
public void extraAction() {
    attack();
}

public void attack() {
    System.out.println("던지면 아픕니다.");
}
```

### CleanerClass에 출력부분과 기능들을 만들어준다.
```java
@Override
public void showObjectInfoBase() {
    System.out.println();
    System.out.println("로봇청소기");
    super.showObjectInfoBase();
}

@Override
public void doAction() {
    System.out.println("청소를 합니다.");
}

@Override
public void extraAction() {
    miss();
}

public void miss() {
    System.out.println("장애물을 피하지 못합니다.");
}
```

### 무결성 검사를 위해 변수들에 private로 바꾸고 shopClass의 메서드를 private로 바꾼다.

### shopClass에 작업순서 메서드를 만들어준다.
```java
public void startAction() {
        inputObjectCount();
        inputObjectInfo();
        showtObjectInfo();
    }
```

### MainClass기본 출력문을 삭제하고 수정해준다.
```java
public class MainClass {
    public static void main(String[] args) {
        ShopClass shopClass = new ShopClass();
        shopClass.startAction();
    }
}
```
--- 추가작업
### shopClass에 전체 상품의 개수를 출력하는 기능을만들어준다.
```java
private void showtObjectInfo(){
    for (int i = 0; i < ObjectArray.length; i++) {
        ObjectArray[i].showObjectInfoBase();
        ObjectArray[i].doAction();
        ObjectArray[i].extraAction();
    }
    System.out.println();
    System.out.printf("전체 상품의 개수 : %d개", ObjectCount);
}
```

### ObjectClass에 가격의 정보를 전송하는 메서드를만들어준다.
```java
// 가격의 정보를 전송하는 메서드
public int returnPrice () {
    return Price;
}
```

### ShopClass에 총가격과 평균가격 변수를만들어준다.
```java
// 총 가격
private int totalPrice;
// 평균 가격
private int avgPrice;
```

### ShopClass에 showtObjectInfo메서드 안에 총가격과 평균가격이 출력되게 수정해준다.
```java
private void showtObjectInfo(){
    for (int i = 0; i < ObjectArray.length; i++) {
        totalPrice = totalPrice + ObjectArray[i].getTotalPrice();
        ObjectArray[i].showObjectInfoBase();
        ObjectArray[i].doAction();
        ObjectArray[i].extraAction();
    }
    avgPrice = totalPrice / ObjectCount;
    System.out.println();
    System.out.printf("전체 상품의 개수 : %d개\n", ObjectCount);
    System.out.printf("총 가격 : %d원\n", totalPrice);
    System.out.printf("평균 가격 : %d원\n", avgPrice);
}
```